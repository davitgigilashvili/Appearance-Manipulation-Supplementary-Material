%This is a general script, which automatically adapts based on 
% the presence or absence of the negative values in the difference image, 
%decides whether boosting is needed, 
% and calculates the compensation image accordingly.
clc;clear;close all;

gamma = 2.2;

%Read original and target images
orig = imread([pwd filesep 'original.png']);
target = imread([pwd filesep 'target.png']);

%Convert them to double and remove gamma
linorig = (double(orig)/255).^(gamma);
lintarget = (double(target)/255).^(gamma);

%Calculate the difference between the target and the original
lindiff = lintarget-linorig;
%Find the minimum in the difference image
[minval,minidx] = min(lindiff(:));

if minval<0 % if nevative values are present in the difference image, 
            % the target image is boosted, so the negatives are brought up
            % above zero in the compensation image
    boostF = linorig(minidx)/lintarget(minidx);
    lintargetboost = lintarget*boostF;
    lincomp = lintargetboost-linorig;
else
    lincomp = lindiff; % if there are no negative values, the compensation
                       % image is simply the difference
end

linresult = linorig+lincomp;
result = uint8((linresult.^(1/gamma))*255);
figure,imshow(result) % this image is probably clipped, it just serves to 
                      % display what the AR result will look like in
                      % reality (where no clipping occurs)
title('expected result (probably clipped)')

pause(0.2)

comp = uint8((lincomp.^(1/gamma))*255); % the compensation image for AR
figure,imshow(comp)
%imwrite(comp,[pwd filesep 'compensation.png'])
title('compensation image')

pause(0.2)

figure,imshow(orig)
title('original image')

pause(0.2)

figure,imshow(target)
title('target image')