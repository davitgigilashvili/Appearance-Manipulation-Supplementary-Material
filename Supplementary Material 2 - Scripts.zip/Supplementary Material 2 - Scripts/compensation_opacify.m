clear all, close all, clc;

gamma = 2.2;

%Define boosting factor
boostF = 1;

%Read translucent and opaque images
tranlimg = imread([pwd filesep '70.png']);
opaqimg = imread([pwd filesep '1000.png']);
%Convert to double and remove gamma
lintranlimg = (double(tranlimg)/255).^(gamma);
linopaqimg = (double(opaqimg)/255).^(gamma);
%Calculate boosted (scaled up) image
lintranlimg_boost = lintranlimg * boostF;
%Calculate difference image
lindiff = linopaqimg-lintranlimg;
%Calculate compensation image
compensation = lintranlimg_boost + lindiff;
boost = uint8((lintranlimg_boost.^(1/gamma))*255);
compimg = uint8((compensation.^(1/gamma))*255);

figure,imshow(compimg); 
figure,imshow(boost);
%imwrite(compimg,[pwd filesep 'compensation.png']);
%imwrite(boost,[pwd filesep 'boost.png']);